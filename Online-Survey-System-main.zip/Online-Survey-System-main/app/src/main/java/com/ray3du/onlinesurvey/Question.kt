package com.ray3du.onlinesurvey

data class Question(
        val quizNumber: String? = null,
        val quiz: String? = null
)